# No. 04 Eau de Parfum — launch kit

Brand: AUREL
Engine: template

## Confirmed seller facts
Eau de parfum
50 ml glass bottle
Notes of bergamot, iris and cedar
Spray applicator
Presented in a paper box

## Listing title
No. 04 Eau de Parfum | Eau de parfum | AUREL

## Description
No. 04 Eau de Parfum, by AUREL.

Eau de parfum. 50 ml glass bottle. Notes of bergamot, iris and cedar. Spray applicator. Presented in a paper box.

Price: USD 68.

Discover No. 04.

## Highlights
- Eau de parfum
- 50 ml glass bottle
- Notes of bergamot, iris and cedar
- Spray applicator
- Presented in a paper box

## Keyword ideas (not validated search data)
no 04 eau de parfum, beauty  care, eau de parfum, 50 ml glass bottle, notes of bergamot iris and cedar, spray applicator

## Instagram
Meet No. 04 Eau de Parfum.

Eau de parfum. 50 ml glass bottle. Notes of bergamot, iris and cedar. Spray applicator. Presented in a paper box.

USD 68
Discover No. 04.

#no04eaudeparfum #beautycare #eaudeparfum #50mlglassbottle #notesofbergamotirisandcedar

## WhatsApp
Meet No. 04 Eau de Parfum from AUREL.

• Eau de parfum
• 50 ml glass bottle
• Notes of bergamot, iris and cedar
• Spray applicator
• Presented in a paper box

USD 68
Discover No. 04.

## Email
Subject: No. 04 Eau de Parfum has arrived

Meet No. 04 Eau de Parfum, from AUREL.

Eau de parfum. 50 ml glass bottle. Notes of bergamot, iris and cedar. Spray applicator. Presented in a paper box.

Price: USD 68.

Discover No. 04.

## Before publishing
- Confirm delivery regions and processing time.
- Add care instructions, materials and dimensions if relevant.
- Check returns, stock and any claims before publishing.

Review every asset and claim before publishing. This kit does not publish to any platform.
